import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { loginUserService, registerUserService } from "../services/user.service.js";
import { verifyEmailService,generateAndSendVerificationEmail } from "../services/email-verification.service.js";
import { revokeRefreshToken } from "../repositories/refresh-token.repository.js";

const registeruser = asyncHandler(async (req, res) => {
  const { name,username, email, password, role } = req.body;
  const avatarLocalPath = req.files?.avatar?.[0]?.path;

  const user = await registerUserService({
    name,
    username,
    email,
    password,
    role,
    avatarLocalPath,
  });

  return res.status(201).json(
    new ApiResponse(
      201,
      user,
      "User registered successfully"
    )
  );
});

const verifyEmail = asyncHandler(async (req,res) => {
  const { token } = req.query;

  await verifyEmailService(token);

  return res.status(200).json(
    new ApiResponse(
      200,
      {},
      "Email verified successfully"
    )
  )
});

const resendVerificationEmail = asyncHandler(async (req, res) => {
  const { email } = req.body;

  if (!email?.trim()) {
    throw new ApiError(400, "Email is required");
  }

  const normalizedEmail = email.toLowerCase().trim();
  const user = await getUser({ email: normalizedEmail, username: "" });

  // Always return the same success response whether or not the account
  // exists — prevents leaking which emails are registered.
  if (user && !user.is_email_verified) {
    await generateAndSendVerificationEmail(user);
  }

  return res.status(200).json(
    new ApiResponse(200, {}, "If an account with that email exists and is unverified, a verification link has been sent.")
  );
});

const loginUser = asyncHandler(async (req, res) => {
  const { email, username, password } = req.body;

  const loggedUser = await loginUserService({ email, username, password });

  const options ={
    httpOnly: true,
    secure: true,
    sameSite: "strict"
  }
  return res.status(200)
  .cookie("accessToken", loggedUser.accessToken, options)
  .cookie("refreshToken", loggedUser.refreshToken, options)
  .json(new ApiResponse(200,loggedUser.user,"User logged in successfully"))
});

// profile related controllers
const getUserProfile = asyncHandler(async (req, res) => {
  const user = req.user; // Assuming user is attached to the request object after authentication

  return res.status(200).json(
    new ApiResponse(
      200,
      user,
      "User profile retrieved successfully"
    )
  );
});

const logoutUser = asyncHandler(async (req, res) => {
  const refreshToken = req.cookies?.refreshToken;

  if (refreshToken) {
    await revokeRefreshToken(refreshToken); // mark this device's token as revoked in DB
  }

  const options = {
    httpOnly: true,
    secure: true,
    sameSite: "strict",
  };

  return res
    .status(200)
    .clearCookie("accessToken", options)
    .clearCookie("refreshToken", options)
    .json(new ApiResponse(200, {}, "User logged out successfully"));
});

const forgeotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;

  if(!email?.trim()){
    new ApiError(400, "Email is required");
  }
  const normalizedEmail = email.toLowerCase().trim();
  const user = await getUser({ email: normalizedEmail, username: "" });

  if(!user){
    
  }

  return res.status(200).json(
}
export { registeruser, getUserProfile, loginUser , verifyEmail, resendVerificationEmail, logoutUser, forgeotPassword };